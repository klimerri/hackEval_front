import os
import sys
import json
import re

AWS_KEY = "AKIAIOSFODNN7EXAMPLE"
API_KEY = "api_key = 1234567890abcdef1234"
password = "supersecret123"

def f(a,b,c,d,e):
    x=0
    if a>0:
        if b>0:
            if c>0:
                if d>0:
                    if e>0:
                        x=a+b+c+d+e
                    else:
                        x=a
                else:
                    x=b
            else:
                x=c
        else:
            x=d
    else:
        x=e
    return x

def g( y ):
    unused = 123
    result=[]
    for i in range(y):
        for j in range(y):
            result.append(i*j)
    return result

print(f(1,2,3,4,5))
