"""Task tracker core."""
from dataclasses import dataclass, field


@dataclass
class Task:
    title: str
    done: bool = False


@dataclass
class Tracker:
    tasks: list[Task] = field(default_factory=list)

    def add(self, title: str) -> Task:
        task = Task(title=title)
        self.tasks.append(task)
        return task

    def complete(self, index: int) -> None:
        self.tasks[index].done = True

    def pending(self) -> list[Task]:
        return [t for t in self.tasks if not t.done]


def main() -> None:
    tracker = Tracker()
    tracker.add("write docs")
    tracker.add("ship mvp")
    tracker.complete(0)
    print(f"pending: {len(tracker.pending())}")


if __name__ == "__main__":
    main()
