from src.app import Tracker


def test_pending():
    t = Tracker()
    t.add("a")
    t.add("b")
    t.complete(0)
    assert len(t.pending()) == 1
